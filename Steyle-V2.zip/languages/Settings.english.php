<?php
// Version: 2.1.0; Settings

global $settings;

// argument(s): images_url as saved in settings
$txt['theme_thumbnail_href'] = '%1$s/thumbnail.png';
$txt['theme_description'] = '<a href="https://webtiryaki.com">Siteyle V2 Theme</a> by <a href="https://webtiryaki.com/index.php?action=profile;u=2"></a>';

?>