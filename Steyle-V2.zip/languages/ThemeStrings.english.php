<?php
// Version: 2.1 2; index
$txt['header_fa'] = "Add an Icon to Header Title:";
$txt['menu_buttons_settings'] = "Find <a href='https://icofont.com/icons' target='_blank'>All Icons</a>";

$txt['wt_enabled'] = 'Enable Footer Menu';
$txt['wt_enabled_desc'] = 'Include https:// on your Footer Links';
$txt['wt_footer1'] = 'Heading #1 h3';
$txt['wt_footer2'] = 'Heading #2 h3';
$txt['wt_footer3'] = 'Heading #3 h3';
$txt['wt_footer4'] = 'Heading #4 h3';
$txt['wt_title1'] = 'Title 1';
$txt['wt_url1'] = 'url 1';
$txt['wt_title2'] = 'Title 2';
$txt['wt_url2'] = 'url 2';
$txt['wt_title3'] = 'Title 3';
$txt['wt_url3'] = 'url 3';
$txt['wt_title4'] = 'Title 4';
$txt['wt_url4'] = 'url 4';
$txt['wt_title5'] = 'Title 5';
$txt['wt_url5'] = 'url 5';
$txt['wt_title6'] = 'Title 6';
$txt['wt_url6'] = 'url 6';
$txt['wt_title7'] = 'Title 7';
$txt['wt_url7'] = 'url 7';
$txt['wt_title8'] = 'Title 8';
$txt['wt_url8'] = 'url 8';
$txt['wt_title9'] = 'Title 9';
$txt['wt_url9'] = 'url 9';
$txt['wt_title10'] = 'Title 10';
$txt['wt_url10'] = 'url 10';
$txt['wt_title11'] = 'Title 11';
$txt['wt_url11'] = 'url 11';
$txt['wt_title12'] = 'Title 12';
$txt['wt_url12'] = 'url 12';
$txt['wt_title13'] = 'Text field';
?>